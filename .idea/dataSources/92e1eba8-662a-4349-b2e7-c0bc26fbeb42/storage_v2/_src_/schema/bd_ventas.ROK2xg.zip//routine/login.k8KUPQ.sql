create
    definer = root@localhost procedure login(IN _email varchar(50), IN _pass varchar(60))
SELECT us.id,us.email, us.usuario, us.pass,us.estado,us.privilegio FROM usuarios as us
WHERE us.email =  AND us.pass =;

