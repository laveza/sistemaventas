create
    definer = root@localhost procedure registrarUsuario(IN _email varchar(100), IN _usuario varchar(50),
                                                        IN _pass varchar(256), IN _privilegio varchar(50))
INSERT INTO usuarios(email,usuario,pass,privilegio)VALUES(,,,);

