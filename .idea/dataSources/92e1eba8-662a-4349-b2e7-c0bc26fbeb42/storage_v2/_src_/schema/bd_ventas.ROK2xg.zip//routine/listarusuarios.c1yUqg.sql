create
    definer = root@localhost procedure listarusuarios()
SELECT * FROM usuarios;

